import unicodedata

from store.models import Package, Service


def _normalized(value):
    return unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()


def _service_kind(service):
    identity = _normalized(f"{service.slug} {service.name}")
    if service.requires_comments or "coment" in identity:
        return "comments"
    if "curtida" in identity or "like" in identity:
        return "likes"
    if "visualiza" in identity or "view" in identity:
        return "views"
    return "profile"


def _bonus_rule(package):
    kind = _service_kind(package.service)
    if kind == "likes":
        if package.quantity <= 500:
            return "views", 3000
        if package.quantity < 5000:
            return "views", 5000
        return "views", 10000
    if kind == "views":
        if package.quantity >= 50000:
            return "likes", 500
        if package.quantity >= 10000:
            return "likes", 250
    return None


def get_bonus_packages_for_package(package):
    """Return real bonus packages that can use the main order's target."""
    rule = _bonus_rule(package)
    if not rule:
        return []

    desired_kind, desired_quantity = rule
    candidates = (
        Package.objects.filter(
            active=True,
            price_brl__gt=0,
            quantity=desired_quantity,
            service__active=True,
            service__provider_service_id__gt="",
            service__requires_comments=False,
            service__platform=package.service.platform,
        )
        .exclude(service=package.service)
        .select_related("service", "service__platform")
        .order_by("service__position", "position", "id")
    )
    for candidate in candidates:
        if _service_kind(candidate.service) == desired_kind:
            return [candidate]
    return []


def _active_packages_by_level(service):
    packages = list(
        Package.objects.filter(
            service=service,
            active=True,
            price_brl__gt=0,
        ).select_related("service", "service__platform")
    )
    positions = [package.position for package in packages]
    positions_are_reliable = (
        bool(positions)
        and all(position > 0 for position in positions)
        and len(positions) == len(set(positions))
    )
    if positions_are_reliable:
        return [
            (package.position, package)
            for package in sorted(
                packages,
                key=lambda package: (
                    package.position,
                    package.quantity,
                    package.price_brl,
                    package.pk,
                ),
            )
        ]
    ordered_packages = sorted(
        packages,
        key=lambda package: (
            package.quantity,
            package.price_brl,
            package.position,
            package.pk,
        ),
    )
    return list(enumerate(ordered_packages, start=1))


def get_checkout_complements(selected_package):
    """Return at most three paid complements matching the selected package level."""
    main_packages = _active_packages_by_level(selected_package.service)
    try:
        selected_level = next(
            level for level, package in main_packages if package.pk == selected_package.pk
        )
    except StopIteration:
        selected_level = 1

    main_kind = _service_kind(selected_package.service)
    complementary_kinds = {
        "profile": {"likes", "views"},
        "likes": {"views"},
        "views": {"likes"},
        "comments": {"likes", "views"},
    }[main_kind]
    services = (
        Service.objects.filter(
            platform=selected_package.service.platform,
            active=True,
            requires_comments=False,
            provider_service_id__gt="",
        )
        .exclude(pk=selected_package.service_id)
        .order_by("position", "name", "id")
    )

    complements = []
    for service in services:
        if _service_kind(service) not in complementary_kinds:
            continue
        packages = _active_packages_by_level(service)
        if not packages:
            continue
        eligible_packages = [
            (level, package) for level, package in packages if level <= selected_level
        ]
        if not eligible_packages:
            continue
        complements.append(max(eligible_packages, key=lambda item: item[0])[1])
        if len(complements) == 3:
            break
    return complements
