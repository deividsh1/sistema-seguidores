from django.utils import timezone

from store.services.profile_lookup import lookup_profile


def inspect_profile(platform_slug, target):
    """Compatibilidade para chamadas antigas; prefira lookup_profile()."""
    result = lookup_profile(platform_slug, target)
    return {
        "username": result["username"],
        "picture_url": result["profile_picture_url"],
        "is_public": result["is_public"],
        "checked_at": timezone.now(),
        "automatic_validation": False,
    }
