import re
from urllib.parse import urlparse

from django.conf import settings


class ProfileLookupError(Exception):
    pass


def _extract_username(target):
    value = target.strip()
    if value.startswith("@"):
        username = value[1:]
    else:
        path_parts = [part for part in urlparse(value).path.split("/") if part]
        username = path_parts[0].removeprefix("@") if path_parts else ""
    return re.sub(r"[^A-Za-z0-9._]", "", username)[:160]


def _fallback_profile(target):
    username = _extract_username(target)
    if not username:
        raise ProfileLookupError("Informe um @ ou link de perfil válido.")
    return {
        "ok": True,
        "username": username,
        "full_name": "",
        "profile_picture_url": "",
        "is_public": None,
        "message": "Confirme se este é o perfil correto e se está público.",
    }


def lookup_profile(platform, target):
    """Retorna uma prévia padronizada sem expor credenciais ao navegador."""
    platform = platform.strip().lower()
    if platform not in {"instagram", "tiktok"}:
        raise ProfileLookupError("Plataforma inválida.")

    # O fallback é intencional enquanto não houver documentação oficial da API.
    # Quando ela existir, implemente o adaptador aqui usando
    # settings.PROFILE_LOOKUP_PROVIDER e settings.PROFILE_LOOKUP_API_KEY.
    if settings.PROFILE_LOOKUP_SIMULATED:
        return _fallback_profile(target)

    # Não tenta adivinhar endpoints de terceiros. Assim, uma configuração
    # incompleta nunca quebra o checkout nem expõe a chave no frontend.
    return _fallback_profile(target)
