import re
from decimal import Decimal
from urllib.parse import urlparse

from django import forms
from django.conf import settings
from django.utils import timezone

from store.models import Order, OrderItem, Package, TERMS_VERSION
from store.security import get_client_ip
from store.services.catalog import get_bonus_packages_for_package, get_checkout_complements
from store.services.profile_lookup import ProfileLookupError, lookup_profile


PLATFORM_HOSTS = {
    "instagram": {"instagram.com", "www.instagram.com"},
    "tiktok": {"tiktok.com", "www.tiktok.com", "vm.tiktok.com"},
}


def target_field_config(service):
    name = service.name.lower()
    if service.requires_comments or "coment" in name:
        return {
            "kind": "comments",
            "label": "Link do vídeo ou publicação",
            "placeholder": "Cole o link do vídeo, Reels ou publicação",
            "help": "Use o link exato do conteúdo que receberá os comentários.",
        }
    if "curtida" in name:
        return {
            "kind": "likes",
            "label": "Link da Publicação",
            "placeholder": "Cole o link da publicação",
            "help": "Use o link do post que receberá as curtidas.",
        }
    if "visualiza" in name:
        return {
            "kind": "views",
            "label": "Link do Vídeo",
            "placeholder": "Cole o link do vídeo ou Reels",
            "help": "Use o link do vídeo que receberá as visualizações.",
        }
    return {
        "kind": "profile",
        "label": "Link ou @ do Perfil",
        "placeholder": "@usuario ou link do perfil",
        "help": "O perfil precisa estar público.",
    }


class OrderForm(forms.ModelForm):
    comments_text = forms.CharField(
        label="Comentários personalizados",
        max_length=20000,
        required=False,
        widget=forms.Textarea(
            attrs={
                "class": "form-control",
                "rows": 7,
                "placeholder": "Escreva um comentário por linha",
            }
        ),
    )
    upsells = forms.ModelMultipleChoiceField(
        label="Serviços complementares",
        queryset=Package.objects.none(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
    )
    confirm_public_profile = forms.BooleanField(
        required=False,
        initial=True,
        widget=forms.HiddenInput(),
    )
    accept_terms = forms.BooleanField(
        label="Li e concordo com os Termos de Uso.",
        required=True,
        error_messages={"required": "Você precisa aceitar os Termos de Uso."},
    )

    class Meta:
        model = Order
        fields = ("target", "comments_text", "whatsapp", "email")
        widgets = {
            "target": forms.TextInput(
                attrs={"class": "form-control", "placeholder": "@usuario ou link"}
            ),
            "whatsapp": forms.TextInput(
                attrs={"class": "form-control", "placeholder": "(11) 99999-9999"}
            ),
            "email": forms.EmailInput(
                attrs={"class": "form-control", "placeholder": "voce@email.com"}
            ),
        }

    def __init__(self, *args, package, request=None, **kwargs):
        self.package = package
        self.request = request
        super().__init__(*args, **kwargs)
        self.target_config = target_field_config(package.service)
        self.fields["target"].label = self.target_config["label"]
        self.fields["target"].help_text = self.target_config["help"]
        self.fields["target"].widget.attrs["placeholder"] = self.target_config["placeholder"]
        self.fields["email"].required = settings.ORDER_EMAIL_REQUIRED or (
            not settings.PAYMENT_SIMULATED
            and settings.PAYMENT_PROVIDER == "mercadopago"
        )
        self.fields["email"].error_messages.update(
            {
                "required": "Informe um email válido para receber atualizações do pedido.",
                "invalid": "Informe um email válido para receber atualizações do pedido.",
            }
        )
        self.fields["comments_text"].required = package.service.requires_comments
        self.bonus_packages = get_bonus_packages_for_package(package)
        bonus_package_ids = {bonus.pk for bonus in self.bonus_packages}
        complement_ids = [
            complement.pk
            for complement in get_checkout_complements(package)
            if complement.pk not in bonus_package_ids
        ]
        self.fields["upsells"].queryset = (
            Package.objects.filter(pk__in=complement_ids)
            .select_related("service")
            .order_by("service__position", "service__name", "service_id")
        )
        self.fields["accept_terms"].widget.attrs["class"] = "form-check-input"
        self.fields["upsells"].widget.attrs["class"] = "upsell-input"

    def clean_target(self):
        target = self.cleaned_data["target"].strip()
        if target.startswith("@"):
            if self.target_config["kind"] != "profile":
                if self.target_config["kind"] == "comments":
                    raise forms.ValidationError(
                        "Para comentários personalizados, informe o link da foto ou vídeo."
                    )
                raise forms.ValidationError(
                    f"Para {self.package.service.name}, informe o link correto do conteúdo."
                )
            if not re.fullmatch(r"@[A-Za-z0-9._]{2,100}", target):
                raise forms.ValidationError("Informe um @usuário válido.")
            return target

        parsed = urlparse(target)
        platform_slug = self.package.service.platform.slug
        allowed_hosts = PLATFORM_HOSTS.get(platform_slug, set())
        if parsed.scheme not in {"http", "https"} or parsed.hostname not in allowed_hosts:
            raise forms.ValidationError(
                f"Informe um @usuário ou link válido do {self.package.service.platform.name}."
            )
        if self.package.service.requires_comments:
            path_parts = [part for part in parsed.path.split("/") if part]
            if len(path_parts) < 2 or path_parts[0].lower() not in {"p", "reel", "tv"}:
                raise forms.ValidationError(
                    "Para comentários personalizados, informe o link da foto ou vídeo."
                )
        return target

    def clean_whatsapp(self):
        whatsapp = re.sub(r"\D", "", self.cleaned_data["whatsapp"])
        if not 10 <= len(whatsapp) <= 15:
            raise forms.ValidationError("Informe um WhatsApp válido com DDD.")
        return whatsapp

    def clean_comments_text(self):
        if not self.package.service.requires_comments:
            return ""
        comments = [
            line.strip()
            for line in self.cleaned_data.get("comments_text", "").splitlines()
            if line.strip()
        ]
        if len(comments) != self.package.quantity:
            raise forms.ValidationError(
                f"Informe exatamente {self.package.quantity} comentário(s), um por linha."
            )
        return "\n".join(comments)

    def clean_upsells(self):
        upsells = self.cleaned_data["upsells"]
        if len(upsells) > 3:
            raise forms.ValidationError("Escolha no máximo três serviços complementares.")
        service_ids = [package.service_id for package in upsells]
        if len(service_ids) != len(set(service_ids)):
            raise forms.ValidationError("Escolha somente um pacote por serviço complementar.")
        for package in upsells:
            service = package.service
            if service.min_quantity is not None and package.quantity < service.min_quantity:
                raise forms.ValidationError(
                    f"O pacote de {service.name} está abaixo do mínimo permitido."
                )
            if service.max_quantity is not None and package.quantity > service.max_quantity:
                raise forms.ValidationError(
                    f"O pacote de {service.name} está acima do máximo permitido."
                )
        return upsells

    def clean(self):
        cleaned_data = super().clean()
        service = self.package.service
        if not service.provider_service_id:
            raise forms.ValidationError("Este pacote está temporariamente indisponível.")
        if service.min_quantity is not None and self.package.quantity < service.min_quantity:
            raise forms.ValidationError("A quantidade está abaixo do mínimo do serviço.")
        if service.max_quantity is not None and self.package.quantity > service.max_quantity:
            raise forms.ValidationError("A quantidade está acima do máximo do serviço.")
        return cleaned_data

    def save(self, commit=True):
        order = super().save(commit=False)
        order.package = self.package
        order.prepare_values()
        bonus_packages = get_bonus_packages_for_package(self.package)
        bonus_package_ids = {package.pk for package in bonus_packages}
        upsells = [
            package
            for package in self.cleaned_data["upsells"]
            if package.pk not in bonus_package_ids
        ]
        order.amount_brl = self.package.price_brl + sum(
            (package.price_brl for package in upsells), Decimal("0")
        )
        order.accepted_terms = self.cleaned_data["accept_terms"]
        order.accepted_terms_at = timezone.now()
        order.terms_version = TERMS_VERSION
        order.confirmed_public_profile = True

        try:
            profile = lookup_profile(
                self.package.service.platform.slug, self.cleaned_data["target"]
            )
        except ProfileLookupError:
            profile = {
                "username": "",
                "profile_picture_url": "",
                "is_public": None,
            }
        order.profile_username = profile["username"]
        order.profile_picture_url = profile["profile_picture_url"]
        order.profile_is_public = profile["is_public"]
        order.profile_checked_at = timezone.now()

        if self.request:
            order.customer_ip = get_client_ip(self.request)
            order.customer_user_agent = self.request.META.get("HTTP_USER_AGENT", "")[:500]

        if commit:
            order.full_clean()
            order.save()
            for package in [self.package, *bonus_packages, *upsells]:
                item = OrderItem(order=order, package=package)
                item.prepare_values()
                if package in bonus_packages:
                    item.package_name = f"Brinde: {item.package_name}"[:120]
                    item.total_amount = Decimal("0")
                item.full_clean()
                item.save()
        return order


class OrderLookupForm(forms.Form):
    code = forms.CharField(
        label="Código do pedido",
        max_length=20,
        widget=forms.TextInput(
            attrs={"class": "form-control", "placeholder": "Ex.: A1B2C3D4E5F6"}
        ),
    )
    contact = forms.CharField(
        label="WhatsApp ou email",
        max_length=254,
        widget=forms.TextInput(
            attrs={"class": "form-control", "placeholder": "Contato usado na compra"}
        ),
    )

    def clean_code(self):
        return self.cleaned_data["code"].strip().upper()
