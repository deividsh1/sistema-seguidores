"use strict";

const brl = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });

const copyButton = document.getElementById("copy-pix");
if (copyButton) {
  copyButton.addEventListener("click", async () => {
    await navigator.clipboard.writeText(document.getElementById("pix-code").value);
    copyButton.textContent = "Copiado";
  });
}

const checkoutForm = document.getElementById("checkout-form");
const packageBenefits = document.getElementById("package-benefits");
if (packageBenefits) {
  const quantity = Number(packageBenefits.dataset.packageQuantity);
  const benefits = ["Suporte no WhatsApp"];

  if (quantity >= 10000) {
    benefits.push(
      "Acompanhamento do pedido",
      "Entrega optimizada",
      "Prioridade na fila de processamento"
    );
  } else if (quantity >= 2000) {
    benefits.push("Acompanhamento do pedido", "Entrega optimizada");
  } else {
    benefits.push("Acompanhamento básico do pedido");
  }

  const list = document.getElementById("package-benefits-list");
  list.replaceChildren(
    ...benefits.map((benefit) => {
      const item = document.createElement("li");
      item.textContent = benefit;
      return item;
    })
  );
}

const targetInput = document.getElementById("id_target");
const profileWarning = document.getElementById("profile-warning");
if (checkoutForm && targetInput && profileWarning) {
  let previewTimer;
  let previewRequest;
  const statusText = profileWarning.querySelector(".target-status-text");
  const targetKind = checkoutForm.dataset.targetKind;

  const setWarning = (message, state = "") => {
    statusText.textContent = message;
    profileWarning.classList.remove("is-loading", "is-ready", "is-private", "is-missing");
    if (state) profileWarning.classList.add(state);
  };

  const updateProfileSuggestion = () => {
    window.clearTimeout(previewTimer);
    if (previewRequest) previewRequest.abort();

    const target = targetInput.value.trim();
    if (target.length < 3) {
      setWarning("Digite o @ ou link correto.");
      return;
    }

    if (targetKind !== "profile") {
      const validLink = /^https?:\/\/\S+$/i.test(target);
      setWarning(
        validLink ? "Link informado. Confira se é o conteúdo correto." : "Cole o link completo do conteúdo.",
        validLink ? "is-ready" : "is-missing"
      );
      return;
    }

    setWarning("Verificando perfil...", "is-loading");

    previewTimer = window.setTimeout(async () => {
      previewRequest = new AbortController();
      const params = new URLSearchParams({
        platform: checkoutForm.dataset.profilePlatform,
        target,
      });
      try {
        const response = await fetch(
          `${checkoutForm.dataset.profilePreviewUrl}?${params.toString()}`,
          { headers: { Accept: "application/json" }, signal: previewRequest.signal }
        );
        const data = await response.json();
        if (!response.ok || !data.ok) throw new Error(data.message || "Prévia indisponível.");

        if (data.is_public === false) {
          setWarning("O perfil não está público. Deixe público para receber.", "is-private");
        } else if (data.is_public === true) {
          setWarning("Perfil encontrado e público.", "is-ready");
        } else {
          setWarning(data.message || "Perfil encontrado. Confirme se está público.", "is-ready");
        }
      } catch (error) {
        if (error.name === "AbortError") return;
        setWarning("Perfil não encontrado. Verifique o @ ou link.", "is-missing");
      }
    }, 700);
  };
  targetInput.addEventListener("input", updateProfileSuggestion);
  updateProfileSuggestion();
}

if (checkoutForm) {
  const inputs = [...document.querySelectorAll(".upsell-input")];
  const totalOutput = document.getElementById("checkout-total");
  const summaryItems = document.getElementById("summary-items");
  const upsellFeedback = document.getElementById("upsell-feedback");
  const basePrice = Number(checkoutForm.dataset.basePrice.replace(",", "."));
  const staticItems = [...summaryItems.querySelectorAll(".summary-static-item")].map((item) =>
    item.cloneNode(true)
  );

  const showUpsellFeedback = (message = "") => {
    if (upsellFeedback) upsellFeedback.textContent = message;
  };

  const updateCheckout = () => {
    let total = basePrice;
    summaryItems.replaceChildren(...staticItems.map((item) => item.cloneNode(true)));
    inputs.forEach((input) => {
      const label = input.closest(".upsell-card");
      const toggle = label.querySelector(".upsell-toggle");
      const icon = label.querySelector(".upsell-icon");
      toggle.textContent = input.checked ? "Remover" : "Adicionar";
      icon.textContent = input.checked ? "✓" : input.dataset.icon;
      label.classList.toggle("is-selected", input.checked);
      if (!input.checked) return;
      const price = Number(input.dataset.price.replace(",", "."));
      total += price;
      const item = document.createElement("div");
      const name = document.createElement("span");
      const amount = document.createElement("b");
      name.textContent = input.dataset.label;
      amount.textContent = brl.format(price);
      item.append(name, amount);
      summaryItems.append(item);
    });
    totalOutput.textContent = brl.format(total);
  };

  const validateUpsellSelection = (input) => {
    showUpsellFeedback();
    if (!input.checked) return true;

    const selected = inputs.filter((candidate) => candidate.checked);
    const sameService = selected.filter(
      (candidate) => candidate.dataset.serviceKey === input.dataset.serviceKey
    );
    if (sameService.length > 1) {
      input.checked = false;
      showUpsellFeedback("Escolha somente um pacote por serviço complementar.");
      return false;
    }
    if (selected.length > 3) {
      input.checked = false;
      showUpsellFeedback("Você pode adicionar no máximo três complementos.");
      return false;
    }
    return true;
  };

  inputs.forEach((input) =>
    input.addEventListener("change", () => {
      validateUpsellSelection(input);
      updateCheckout();
    })
  );
  updateCheckout();
}

const activityToast = document.getElementById("activity-toast");
if (activityToast && !checkoutForm) {
  const activities = [
    ["Mariana", "acabou de comprar 500 seguidores para Instagram"],
    ["Lucas", "acabou de comprar 1.000 curtidas para TikTok"],
    ["Ana", "comprou 3.000 visualizações para Reels"],
    ["Pedro", "acabou de comprar 10 comentários personalizados"],
    ["Camila", "acabou de comprar 500 curtidas para Instagram"],
    ["Cliente de São Paulo", "comprou 1.000 seguidores para Instagram"],
    ["Rafael", "comprou 5.000 visualizações para Reels"],
    ["Bianca", "acabou de comprar 250 curtidas para TikTok"],
  ];
  const used = new Set(JSON.parse(sessionStorage.getItem("webmaster-activity-used") || "[]"));
  const showActivity = () => {
    let available = activities.map((_, index) => index).filter((index) => !used.has(index));
    if (!available.length) {
      used.clear();
      available = activities.map((_, index) => index);
    }
    const index = available[Math.floor(Math.random() * available.length)];
    used.add(index);
    sessionStorage.setItem("webmaster-activity-used", JSON.stringify([...used]));
    document.getElementById("activity-name").textContent = activities[index][0];
    document.getElementById("activity-message").textContent = activities[index][1];
    activityToast.hidden = false;
    requestAnimationFrame(() => activityToast.classList.add("is-visible"));
    setTimeout(() => activityToast.classList.remove("is-visible"), 5000);
  };
  setTimeout(showActivity, 8000);
  setInterval(showActivity, 30000);
}
